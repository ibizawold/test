# redtube

redrube.com is an Adult over 18's Internet service that provides video hosting services. Users can add, view, comment and share these or other videos. The site includes a professionally shot movies and clips as well as amateur videos.

#### Supported url parameters

 Name       | Description
------------|-------------
 language   | interface language can be one of the supported interface language (see below)
 regionCode | content will be relevant to the selected country. The parameter value is an ISO 3166-1 alpha-2 country code.
 config     | url encoded path to file which control menu items, if not provided, use https://raw.githubusercontent.com/GeraldBrooks/youtube/master/config.json


#### Supported interface languages

 Value | Description
-------|-------------
 en    | English
 ru    | Русский
 uk    | Українська
 de    | Deutsch
 ar    | Arabian
